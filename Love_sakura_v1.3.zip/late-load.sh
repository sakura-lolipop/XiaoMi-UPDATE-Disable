#!/system/bin/sh
# KSU late-load 模式：exploit 触发瞬间即应用（post-fs-data 不执行的替代）
MODDIR=${0%/*}
RP=""
for p in /data/adb/ksu/bin/resetprop /data/adb/magisk/resetprop /data/adb/ap/bin/resetprop; do
  [ -x "$p" ] && RP="$p" && break
done
[ -z "$RP" ] && RP=$(command -v resetprop 2>/dev/null)
[ -z "$RP" ] && exit 0
for k in ro.mi.os.version.incremental ro.mi.os.version.name ro.mi.os.version.code ro.build.version.incremental ro.system.build.version.incremental; do
  "$RP" "$k" Love 2>/dev/null
done
"$RP" ro.mi.xms.version.incremental 🌸 2>/dev/null

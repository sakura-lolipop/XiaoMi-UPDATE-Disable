#!/system/bin/sh
# 常规模式兜底：等 boot 完成后再应用一次（幂等）
MODDIR=${0%/*}
RP=""
for p in /data/adb/ksu/bin/resetprop /data/adb/magisk/resetprop /data/adb/ap/bin/resetprop; do
  [ -x "$p" ] && RP="$p" && break
done
[ -z "$RP" ] && RP=$(command -v resetprop 2>/dev/null)
[ -z "$RP" ] && exit 0
(
  while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
  for k in ro.mi.os.version.incremental ro.mi.os.version.name ro.mi.os.version.code ro.build.version.incremental ro.system.build.version.incremental; do
    "$RP" "$k" Love 2>/dev/null
  done
"$RP" ro.mi.xms.version.incremental 🌸 2>/dev/null
  sleep 10
  for k in ro.mi.os.version.incremental ro.mi.os.version.name ro.mi.os.version.code ro.build.version.incremental ro.system.build.version.incremental; do
    "$RP" "$k" Love 2>/dev/null
  done
) &

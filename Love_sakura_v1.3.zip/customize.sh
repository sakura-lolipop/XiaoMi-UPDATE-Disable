ui_print "- Updater Love Spoof v1.0-Love.樱花"
ui_print "- 将版本号毒化为 Love.樱花 (实验)"
ui_print "- 前提: 手机需已安装 nogate 版 PoC,"
ui_print "  否则提权链会死在 native 门控"
ui_print "- 卸载本模块并重启即恢复原版本号"
set_perm_recursive "$MODPATH" 0 0 0755 0644

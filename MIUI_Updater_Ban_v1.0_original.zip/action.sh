#!/system/bin/sh

package="com.android.updater"

if cmd package path "$package" >/dev/null 2>&1; then
    if cmd package uninstall --user 0 "$package"; then
        echo "[信息] 系统更新已经卸载 🎯"
    else
        echo "[错误] 系统更新卸载失败 😭"
    fi
else
    if cmd package install-existing "$package"; then
        echo "[信息] 系统更新已经还原 🪤"
    else
        echo "[错误] 系统更新还原失败 😡"
    fi
fi

sleep 1
